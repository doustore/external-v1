import SwiftUI
import AVKit

struct ContentView: View {
    @State private var keyInput: String = ""
    @State private var isAuthenticated: Bool = false
    @State private var errorMessage: String = ""

    var body: some View {
        ZStack {
            Color(hex: "#121212").ignoresSafeArea()

            if isAuthenticated {
                // Pantalla de Bienvenida con el video integrado
                VStack(spacing: 20) {
                    Text("EXTERNAL V1")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(Color(hex: "#1DB954"))
                    
                    Text("Bienvenido - Reproduciendo video de bienvenida")
                        .foregroundColor(.white)
                        .font(.subheadline)

                    // Reproductor de video integrado para la bienvenida
                    WelcomeVideoPlayerView()
                        .frame(height: 250)
                        .cornerRadius(12)
                        .padding(.horizontal)

                    Spacer()
                }
                .padding(.top, 40)
            } else {
                VStack(spacing: 25) {
                    Image(systemName: "music.note.circle.fill")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .foregroundColor(Color(hex: "#1DB954"))

                    Text("EXTERNAL V1")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)

                    Text("Diseño Spotify - Introduce tu KEY")
                        .font(.subheadline)
                        .foregroundColor(Color(hex: "#B3B3B3"))

                    SecureField("KEY (Ej: 123)", text: $keyInput)
                        .textFieldStyle(PlainTextFieldStyle())
                        .padding()
                        .background(Color(hex: "#282828"))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        .padding(.horizontal, 40)

                    if !errorMessage.isEmpty {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.caption)
                    }

                    Button(action: {
                        if keyInput == "123" {
                            isAuthenticated = true
                            errorMessage = ""
                        } else {
                            errorMessage = "KEY incorrecta. Usa la KEY: 123"
                        }
                    }) {
                        Text("ENTRAR")
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(hex: "#1DB954"))
                            .cornerRadius(25)
                    }
                    .padding(.horizontal, 40)

                    Spacer()
                }
                .padding(.top, 60)
            }
        }
    }
}

struct WelcomeVideoPlayerView: View {
    var body: some View {
        // Vista simulada de reproductor AVPlayer para el video de bienvenida integrado
        ZStack {
            Color.black
            VStack {
                Image(systemName: "play.circle.fill")
                    .font(.system(size: 50))
                    .foregroundColor(Color(hex: "#1DB954"))
                Text("Video de Bienvenida (video_1.mp4)")
                    .foregroundColor(.white)
                    .font(.caption)
                    .padding(.top, 8)
            }
        }
    }
}

extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        scanner.currentIndex = hex.index(after: hex.startIndex)
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)
        let r = Double((rgbValue & 0xFF0000) >> 16) / 255.0
        let g = Double((rgbValue & 0x00FF00) >> 8) / 255.0
        let b = Double(rgbValue & 0x0000FF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}
