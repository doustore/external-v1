# EXTERNAL V1 - App 3105 con Video de Bienvenida

- **Diseño**: Estilo Spotify (`#121212` y `#1DB954`).
- **KEY de Prueba**: `123`.
- **Bienvenida**: Video integrado (`video_1.mp4`) en la pantalla de bienvenida al introducir la KEY correcta.
